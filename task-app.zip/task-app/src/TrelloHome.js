import React from "react";
import initialData from "./initial-data";
import ColumnList from "./ColumnList";

import { DragDropContext } from "react-beautiful-dnd";
import "@atlaskit/css-reset";

class TrelloHome extends React.Component {
  state = initialData;
  counter = 9;
  onDragStart = result => {
    console.log(result);
  };
  onDragUpdate = result => {
    console.log(result);
  };

  onDragEnd = result => {
    console.log(result);
    const { source, destination, draggableId } = result;
    if (!draggableId || !destination) return;
    if (
      source.droppableId === destination.droppableId &&
      source.index === destination.index
    )
      return;
    const column = this.state.columns[source.droppableId];
    const newTaskIds = Array.from(column.taskIds);
    newTaskIds.splice(source.index, 1);

    const newColumn = {
      ...column,
      taskIds: newTaskIds
    };
    const newState = {
      ...this.state,
      columns: {
        ...this.state.columns,
        [newColumn.id]: newColumn
      }
    };
    const columnD = newState.columns[destination.droppableId];
    const newTaskIdsD = Array.from(columnD.taskIds);

    newTaskIdsD.splice(destination.index, 0, draggableId);
    const newColumnD = {
      ...columnD,
      taskIds: newTaskIdsD
    };
    const newStateD = {
      ...newState,
      columns: {
        ...newState.columns,
        [newColumnD.id]: newColumnD
      }
    };

    this.setState(newStateD);
  };
  onAdd = content => {
    console.log(content);
    const id = "task-" + this.counter;
    const tasks = Array.from(this.state.tasks);
    tasks[id] = {
      id,
      content
    };
    this.setState({ ...this.state, tasks });
    this.counter += 1;
  };
  render() {
    return (
      <DragDropContext
        onDragStart={this.onDragEnd}
        onDragUpdate={this.onDragUpdate}
        onDragEnd={this.onDragEnd}
      >
        <div>
          <ColumnList
            columnOrder={this.state.columnOrder}
            columns={this.state.columns}
            tasks={this.state.tasks}
            onAdd={this.onAdd}
          />
        </div>
      </DragDropContext>
    );
    // });
  }
}

export default TrelloHome;
