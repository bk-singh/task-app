import React from "react";
import TrelloHome from "./TrelloHome";
import "./App.css";
function App() {
  return (
    <div className="App">
      <div style={{ margin: "20px" }}>
        <div className="title">oh.tasks</div>
        <div style={{ margin: "20px" }}>
          <TrelloHome key="home" />
        </div>
      </div>
    </div>
  );
}

export default App;
