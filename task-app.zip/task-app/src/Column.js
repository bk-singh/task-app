import React from "react";

import Task from "./Task";
import styled from "styled-components";
const Container = styled.div`
  margin: 8px;
`;

const TaskList = styled.div`
  padding: 8px;
`;
export default class Column extends React.Component {
  render() {
    return (
      <Container>
        <TaskList>
          {this.props.tasks.map((t, i) => (
            <Task key={t.id} task={t} index={i}></Task>
          ))}
        </TaskList>
      </Container>
    );
  }
}
