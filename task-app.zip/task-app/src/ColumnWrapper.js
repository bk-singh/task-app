import React from "react";
import styled from "styled-components";
import Column from "./Column";

const Container = styled.div`
  margin: 8px;
`;
const Title = styled.h3`
  padding: 8px;
`;
const ColumnList = styled.div`
  padding: 8px;
`;
export default class ColumnWrapper extends React.Component {
  render() {
    return (
      <Container>
        <Title className="status-name">{this.props.column.title}</Title>
        <ColumnList>
          <Column
            key={this.props.column.id}
            column={this.props.column}
            tasks={this.props.tasks}
          />
        </ColumnList>
      </Container>
    );
  }
}
