import React from "react";
import { Droppable } from "react-beautiful-dnd";
import "@atlaskit/css-reset";
import ColumnWrapper from "./ColumnWrapper";
import styled from "styled-components";

const grid = 8;
const getListStyle = isDraggingOver => ({
  background: isDraggingOver ? "skyblue" : "white",
  padding: grid
});
const Container = styled.div`
  margin: 8px;
  border: 1px solid lightgrey;
  border-radius: 5px;
  width: 30%;
  float: left;
`;

class ColumnList extends React.Component {
  render() {
    return this.props.columnOrder.map(columnId => {
      const column = this.props.columns[columnId];
      const tasks = column.taskIds.map(taskId => this.props.tasks[taskId]);
      return (
        <Droppable droppableId={column.id} key={column.id}>
          {(provided, snapshot) => (
            <Container {...provided.droppableProps} ref={provided.innerRef}>
              <div style={getListStyle(snapshot.isDraggingOver)}>
                <ColumnWrapper
                  key={column.id}
                  column={column}
                  tasks={tasks}
                  onAdd={this.props.onAdd}
                />
                {provided.placeholder}
              </div>
            </Container>
          )}
        </Droppable>
      );
    });
  }
}

export default ColumnList;
